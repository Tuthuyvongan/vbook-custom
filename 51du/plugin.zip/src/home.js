function execute() {
  return Response.success([
    { title: "首页", input: "https://www.51du.org/", script: "gen.js" },
  ]);
}
