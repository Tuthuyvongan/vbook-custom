function execute() {
  return Response.success([
    { title: "首页", input: "https://www.23meigui.com/", script: "gen.js" },
  ]);
}
